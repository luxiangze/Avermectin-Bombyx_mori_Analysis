# nf-core/configs: EMBL HD Cluster Configuration

To use, run the pipeline with `-profile embl_hd`. This will download and launch the [`embl_hd.config`](../conf/embl_hd.config) which has been pre-configured with a setup suitable for the embl cluster.
