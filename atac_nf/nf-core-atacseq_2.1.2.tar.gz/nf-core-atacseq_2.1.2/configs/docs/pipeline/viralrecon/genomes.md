# nf-core/configs: viralrecon specific configuration

Extra specific configuration for viralrecon pipeline

## Usage

Will be used automatically when running the pipeline with the shared configs in the nf-core/configs repository

This will download and launch the viralrecon specific [`viralrecon.config`](../../../conf/pipeline/viralrecon/genomes.config) which has been pre-configured with custom genomes.
