# nf-core/configs: Software licenses set up for nf-core

To use, run the pipeline with `-profile software_license`. This will download and launch
the [`software_license.config`](../conf/software_license.config) which has been pre-configured with a
setup suitable for using _Sentieon_ within the nf-core GHA.
