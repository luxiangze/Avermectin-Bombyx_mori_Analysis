# nf-core/configs: awsbatch Configuration

To be used with `awsbatch`.
Custom queue and region can be supplied with `params.awsqueue`, `params.awsregion`, `params.awscli`, respectively.

Allow `overwrite` of `trace`, `timeline`, `report` and `dag` to allow resuming pipelines.
