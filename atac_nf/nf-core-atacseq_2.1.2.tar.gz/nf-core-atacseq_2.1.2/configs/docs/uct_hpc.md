# nf-core/configs: UCT HPC config

University of Cape Town [High Performance Cluster](http://hpc.uct.ac.za/index.php/hpc-cluster/) config.

For help or more information, please contact Katie Lennard (@kviljoen).
